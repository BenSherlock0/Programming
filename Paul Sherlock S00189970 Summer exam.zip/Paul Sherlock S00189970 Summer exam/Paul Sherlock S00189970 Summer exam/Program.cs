﻿// Paul Sherlock S00189970 16/5/19 Final Exam Q1
using System;
using static System.Console;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Paul_Sherlock_S00189970_Summer_exam
{
    class Program
    {
        static double[] sales = new double[5];
        static int[] tickets = new int[5];
        static string[] name = new string[] { "Basic", "Super", "Delux", "VIP", "Total"};
        /*
         * 0 = Basic
         * 1 = Super
         * 2 = Delux
         * 3 = VIP
         * 4 = All
        */
        static void Main(string[] args)
        {
            OutputEncoding = System.Text.Encoding.UTF8; //Euro

            string[] fields = new string[3];//To store each word

            string tableformat = "{0,-20}{1,-20}{2,-20:c}"; //set up the table
            string lineIn;

            int amount = 0;

            try
            {
                FileStream fs = new FileStream("ticketsales.txt", FileMode.Open, FileAccess.Read); //open doc
                StreamReader inputstream = new StreamReader(fs);
                lineIn = inputstream.ReadLine(); //read each line

                WriteLine(tableformat, "Ticket Type", "Tickets sold", "Total Retail value\n");

                //read doc
                while (lineIn != null) 
                {
                    fields = lineIn.Split(',');
                    int.TryParse(fields[2], out amount); // change to int

                    ticket_type(fields[1], amount); //assign values
                    tickets[4] = (tickets[4] + amount); //get total
                    lineIn = inputstream.ReadLine(); //next line
                }
                inputstream.Close();//close notepad
                sales[4] = (sales[0] + sales[1] + sales[2] + sales[3]); //get total

                for (int counter = 0; counter < sales.Length; counter++)
                {
                    WriteLine(tableformat, name[counter], tickets[counter], sales[counter]); //print
                }
            }
            catch(FileNotFoundException) //no file found
            {
                WriteLine("Missing File or misspelled file"); //error report
            }
         
        }
        static void ticket_type(string ticket, int amount)
        {
            switch(ticket) //find name
            {
                case "Basic":
                    tickets[0] = (tickets[0] + amount);
                    sales[0] = (sales[0]+(amount * 40.00));
                    break;
                case "Super":
                    tickets[1] = (tickets[1] + amount);
                    sales[1] = (sales[1]+(amount * 45.00));
                    break;
                case "Delux":
                    tickets[2] = (tickets[2] + amount);
                    sales[2] = (sales[2]+(amount * 55.00));
                    break;
                case "VIP":
                    tickets[3] = (tickets[3] + amount);
                    sales[3] = (sales[3]+ (amount * 60.00));
                    break;
                default:
                    break;

            }
            /*
             * old method
             
            if(ticket == "Basic")
            {
                tickets[0] = (tickets[0] + amount); 
                sales[0] = (amount * 40.00);
            }
            if (ticket == "")
            {
                tickets[0] = (tickets[0] + amount);
                sales[0] = (amount * 40.00);
            }
            */
        }
    }
}
