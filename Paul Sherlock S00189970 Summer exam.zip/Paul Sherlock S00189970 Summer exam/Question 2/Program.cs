﻿//Paul Sherlock S00189970 16/5/19 Final Exam Q2
using System;
using static System.Console;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Bike[] bikeArray = new Bike[4];

            string[] fields = new string[2];
            string lineIn;
            string brand;
            double price;
            int num = 0;

            try
            {
                FileStream fs = new FileStream("bikes.txt", FileMode.Open, FileAccess.Read); //open doc
                StreamReader inputstream = new StreamReader(fs);
                lineIn = inputstream.ReadLine(); //read each line

                while (lineIn != null)
                {
                    fields = lineIn.Split(',');
                    brand = fields[0]; //find name
                    double.TryParse(fields[1], out price); //change to double

                    if (fields[0] != "E-Bike")
                    {
                        bikeArray[num] = new Bike(brand, price); // use subclass
                    }
                    else
                    {
                        bikeArray[num] = new EBike(brand, price); //subclass
                    }

                    num++;

                    lineIn = inputstream.ReadLine(); //next line
                }

                inputstream.Close();//close notepad
            }
            catch(FileNotFoundException) //missing file
            {
                WriteLine("Missing File or misspelled file"); //error report
            }

            for (int counter = 0; counter < bikeArray.Length; counter++) //Print classes
            {
                WriteLine(bikeArray[counter]); 
            }
        }
    }
    class Bike //Main Class
    {
        public static int regCounter;
        private string brand;
        private double price;
        private double deposit;
        private int frame;

        public Bike()
        {
        }
        public Bike(string brand, double price)
        {
            this.brand = brand;
            this.price = price;
            regCounter++;
            frame = regCounter;
            deposit = CalcDeposit(price);
        }

        public string Brand { get => brand; set => brand = value; }
        public double Price { get => price; set => price = value; }
        public int Frame { get; }

        public override string ToString()
        {
            return "Brand Name:" + Brand + "\nUnqiue Num: " + frame   + "\nPrice: " + Price + "\nDeposit: " + deposit + "\n";
        }
        public virtual double CalcDeposit(double price) //get deposit
        {
            double deposit = (price * 0.30); //desposit 30%

            return deposit;
        }
    }
    class EBike : Bike //Subclass
    {
        public EBike(string brand, double price) : base(brand, price) 
        {

        }
        public override double CalcDeposit(double price) // change deposit to 10%
        {
            double deposit = (price * 0.10);

            return deposit;
        }
    }

}
